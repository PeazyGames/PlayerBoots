<?php

namespace PB;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat;
use pocketmine\item\LeatherBoots;
use pocketmine\utils\Color as Colour;
use pocketmine\item\LeatherCap;

class Main extends PluginBase implements Listener {
	public $prefix = "§bPlayer§aBoots §7| ";
	
	public function onEnable(){
		$this->getLogger()->info($this->prefix. "§aDas Plugin wurde geladen :D");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	public function onDisable(){
		$this->getLogger()->info($this->prefix. "§cDas Plugin hatte einen Fehler");
	}
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$player->sendMessage($this->prefix. "§fDir wurden automatisch die §aPlayerBoots §fangezogen");
		
		$boots = Item::get(Item::LEATHER_BOOTS);
		$boots->setCustomColor(new Colour(1, 0, 0));
		$event->getPlayer()->getArmorInventory()->setBoots($boots);
	}
}